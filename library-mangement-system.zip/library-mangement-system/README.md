# Library Management System 

## Description
A RESTful API for managing a library system built with FastAPI.

## Features
- User Authentication (JWT)
- Books CRUD
- Borrowing System
- Role-based Access (Admin/Member)

## Tech Stack
- FastAPI
- PostgreSQL
- SQLAlchemy
- Docker

## How to Run

### With Docker
```bash
docker-compose up --build