import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from main import app
from app.core.models.models import Base
from dependencies.database import get_db
from app.core.models.models import User
from dependencies.auth import hash_password

SQLALCHEMY_TEST_URL = "sqlite:///./test_library.db"
engine = create_engine(SQLALCHEMY_TEST_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture
def member_token(client):
    client.post("/auth/register", json={
        "username": "member1", "email": "member1@test.com", "password": "pass123"
    })
    res = client.post("/auth/login", json={"username": "member1", "password": "pass123"})
    return res.json()["access_token"]


@pytest.fixture
def admin_token(client, db):
    admin = User(
        username="admin1", email="admin1@test.com",
        hashed_password=hash_password("adminpass"), role="admin"
    )
    db.add(admin)
    db.commit()
    res = client.post("/auth/login", json={"username": "admin1", "password": "adminpass"})
    return res.json()["access_token"]


@pytest.fixture
def auth_headers(member_token):
    return {"Authorization": f"Bearer {member_token}"}


@pytest.fixture
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture
def sample_book(client, admin_headers):
    res = client.post("/books/", json={
        "title": "Clean Code", "author": "Robert Martin", "total_copies": 3
    }, headers=admin_headers)
    return res.json()