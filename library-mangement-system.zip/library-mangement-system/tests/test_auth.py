class TestRegister:
    def test_register_success(self, client):
        res = client.post("/auth/register", json={
            "username": "newuser", "email": "new@test.com", "password": "pass123"
        })
        assert res.status_code == 201
        assert res.json()["username"] == "newuser"
        assert res.json()["role"] == "member"

    def test_register_duplicate_username(self, client):
        payload = {"username": "dup", "email": "dup@test.com", "password": "pass"}
        client.post("/auth/register", json=payload)
        res = client.post("/auth/register", json=payload)
        assert res.status_code == 400

    def test_register_missing_fields(self, client):
        res = client.post("/auth/register", json={"username": "only"})
        assert res.status_code == 422


class TestLogin:
    def test_login_success(self, client):
        client.post("/auth/register", json={
            "username": "user1", "email": "u1@test.com", "password": "mypass"
        })
        res = client.post("/auth/login", json={"username": "user1", "password": "mypass"})
        assert res.status_code == 200
        assert "access_token" in res.json()

    def test_login_wrong_password(self, client):
        client.post("/auth/register", json={
            "username": "user2", "email": "u2@test.com", "password": "correct"
        })
        res = client.post("/auth/login", json={"username": "user2", "password": "wrong"})
        assert res.status_code == 401

    def test_login_nonexistent_user(self, client):
        res = client.post("/auth/login", json={"username": "ghost", "password": "pass"})
        assert res.status_code == 401

    def test_access_protected_without_token(self, client):
        res = client.get("/books/")
        assert res.status_code == 401