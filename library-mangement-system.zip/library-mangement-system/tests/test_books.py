class TestBooksCreate:
    def test_admin_can_create_book(self, client, admin_headers):
        res = client.post("/books/", json={
            "title": "Python Tricks", "author": "Dan Bader", "total_copies": 2
        }, headers=admin_headers)
        assert res.status_code == 201
        assert res.json()["title"] == "Python Tricks"

    def test_member_cannot_create_book(self, client, auth_headers):
        res = client.post("/books/", json={
            "title": "Hack", "author": "Bad", "total_copies": 1
        }, headers=auth_headers)
        assert res.status_code == 403


class TestBooksRead:
    def test_get_all_books(self, client, auth_headers, sample_book):
        res = client.get("/books/", headers=auth_headers)
        assert res.status_code == 200
        assert len(res.json()) >= 1

    def test_get_book_by_id(self, client, auth_headers, sample_book):
        res = client.get(f"/books/{sample_book['id']}", headers=auth_headers)
        assert res.status_code == 200

    def test_get_nonexistent_book(self, client, auth_headers):
        res = client.get("/books/9999", headers=auth_headers)
        assert res.status_code == 404

    def test_search_by_title(self, client, auth_headers, sample_book):
        res = client.get("/books/?search=Clean", headers=auth_headers)
        assert res.status_code == 200
        assert any("Clean" in b["title"] for b in res.json())

    def test_filter_by_author(self, client, auth_headers, sample_book):
        res = client.get("/books/?author=Martin", headers=auth_headers)
        assert res.status_code == 200
        assert len(res.json()) >= 1

    def test_pagination(self, client, auth_headers, admin_headers):
        for i in range(5):
            client.post("/books/", json={
                "title": f"Book {i}", "author": "Auth", "total_copies": 1
            }, headers=admin_headers)
        res = client.get("/books/?page=1&limit=3", headers=auth_headers)
        assert len(res.json()) <= 3


class TestBooksUpdate:
    def test_admin_can_update(self, client, admin_headers, sample_book):
        res = client.put(f"/books/{sample_book['id']}", json={"title": "New Title"}, headers=admin_headers)
        assert res.status_code == 200
        assert res.json()["title"] == "New Title"

    def test_member_cannot_update(self, client, auth_headers, sample_book):
        res = client.put(f"/books/{sample_book['id']}", json={"title": "Hack"}, headers=auth_headers)
        assert res.status_code == 403


class TestBooksDelete:
    def test_admin_can_delete(self, client, admin_headers, sample_book):
        res = client.delete(f"/books/{sample_book['id']}", headers=admin_headers)
        assert res.status_code == 204

    def test_member_cannot_delete(self, client, auth_headers, sample_book):
        res = client.delete(f"/books/{sample_book['id']}", headers=auth_headers)
        assert res.status_code == 403


class TestBorrowing:
    def test_borrow_book(self, client, auth_headers, sample_book):
        res = client.post(f"/books/{sample_book['id']}/borrow", headers=auth_headers)
        assert res.status_code == 200
        assert res.json()["is_returned"] == False

    def test_borrow_limit(self, client, auth_headers, admin_headers):
        ids = []
        for i in range(4):
            r = client.post("/books/", json={
                "title": f"Book{i}", "author": "A", "total_copies": 5
            }, headers=admin_headers)
            ids.append(r.json()["id"])
        for i in range(3):
            client.post(f"/books/{ids[i]}/borrow", headers=auth_headers)
        res = client.post(f"/books/{ids[3]}/borrow", headers=auth_headers)
        assert res.status_code == 400
        assert "limit" in res.json()["detail"].lower()

    def test_return_book(self, client, auth_headers, sample_book):
        client.post(f"/books/{sample_book['id']}/borrow", headers=auth_headers)
        res = client.post(f"/books/{sample_book['id']}/return", headers=auth_headers)
        assert res.status_code == 200
        assert res.json()["is_returned"] == True

    def test_return_not_borrowed(self, client, auth_headers, sample_book):
        res = client.post(f"/books/{sample_book['id']}/return", headers=auth_headers)
        assert res.status_code == 404

    def test_borrow_history(self, client, auth_headers, sample_book):
        client.post(f"/books/{sample_book['id']}/borrow", headers=auth_headers)
        res = client.get("/books/history/me", headers=auth_headers)
        assert res.status_code == 200
        assert len(res.json()) >= 1