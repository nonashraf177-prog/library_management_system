from fastapi import FastAPI
from app.core.routes import auth, books
from dependencies.database import engine, Base

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Library Management System")

app.include_router(auth.router)
app.include_router(books.router)

@app.get("/")
def root():
    return {"message": "Library Management System is running"}