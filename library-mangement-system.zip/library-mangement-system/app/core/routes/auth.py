from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.schemas.schemas import UserCreate, UserLogin, UserOut, Token
from app.core.services.auth_service import register_user, login_user
from dependencies.database import get_db

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=UserOut, status_code=201)
def register(user: UserCreate, db: Session = Depends(get_db)):
    return register_user(user, db)


@router.post("/login", response_model=Token)
def login(user: UserLogin, db: Session = Depends(get_db)):
    return login_user(user, db)