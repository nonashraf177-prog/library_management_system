from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.core.schemas.schemas import BookCreate, BookUpdate, BookOut, BorrowOut
from app.core.services import books_service
from dependencies.database import get_db
from dependencies.auth import get_current_user, require_admin

router = APIRouter(prefix="/books", tags=["Books"])


@router.post("/", response_model=BookOut, status_code=201)
def create_book(data: BookCreate, db: Session = Depends(get_db), _=Depends(require_admin)):
    return books_service.create_book(data, db)


@router.get("/", response_model=List[BookOut])
def get_books(
    search: Optional[str] = Query(None),
    author: Optional[str] = Query(None),
    page: int = 1,
    limit: int = 10,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    return books_service.get_books(db, search, author, page, limit)


@router.get("/history/me", response_model=List[BorrowOut])
def my_history(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    return books_service.get_borrow_history(current_user.id, db)


@router.get("/{book_id}", response_model=BookOut)
def get_book(book_id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    return books_service.get_book_by_id(book_id, db)


@router.put("/{book_id}", response_model=BookOut)
def update_book(book_id: int, data: BookUpdate, db: Session = Depends(get_db), _=Depends(require_admin)):
    return books_service.update_book(book_id, data, db)


@router.delete("/{book_id}", status_code=204)
def delete_book(book_id: int, db: Session = Depends(get_db), _=Depends(require_admin)):
    books_service.delete_book(book_id, db)


@router.post("/{book_id}/borrow", response_model=BorrowOut)
def borrow_book(book_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    return books_service.borrow_book(book_id, current_user.id, db)


@router.post("/{book_id}/return", response_model=BorrowOut)
def return_book(book_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    return books_service.return_book(book_id, current_user.id, db)