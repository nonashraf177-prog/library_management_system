from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.orm import declarative_base
from datetime import datetime

Base = declarative_base()


class User(Base):
    _tablename_ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    role = Column(String, default="member")
    is_active = Column(Boolean, default=True)

    borrows = relationship("BorrowRecord", back_populates="user")


class Book(Base):
    _tablename_ = "books"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    author = Column(String)
    available = Column(Boolean, default=True)
    total_copies = Column(Integer, default=1)
    available_copies = Column(Integer, default=1)

    borrows = relationship("BorrowRecord", back_populates="book")


class BorrowRecord(Base):
    _tablename_ = "borrow_records"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    book_id = Column(Integer, ForeignKey("books.id"))
    borrowed_at = Column(DateTime, default=datetime.utcnow)
    returned_at = Column(DateTime, nullable=True)
    is_returned = Column(Boolean, default=False)

    user = relationship("User", back_populates="borrows")
    book = relationship("Book", back_populates="borrows")