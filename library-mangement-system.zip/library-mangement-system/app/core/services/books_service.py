from sqlalchemy.orm import Session
from fastapi import HTTPException
from typing import Optional
from app.core.models.models import Book, BorrowRecord
from app.core.schemas.schemas import BookCreate, BookUpdate


def create_book(data: BookCreate, db: Session):
    book = Book(**data.model_dump(), available_copies=data.total_copies)
    db.add(book)
    db.commit()
    db.refresh(book)
    return book


def get_books(db: Session, search: Optional[str], author: Optional[str], page: int, limit: int):
    query = db.query(Book)
    if search:
        query = query.filter(Book.title.ilike(f"%{search}%"))
    if author:
        query = query.filter(Book.author.ilike(f"%{author}%"))
    return query.offset((page - 1) * limit).limit(limit).all()


def get_book_by_id(book_id: int, db: Session):
    book = db.query(Book).filter(Book.id == book_id).first()
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    return book


def update_book(book_id: int, data: BookUpdate, db: Session):
    book = get_book_by_id(book_id, db)
    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(book, key, value)
    db.commit()
    db.refresh(book)
    return book


def delete_book(book_id: int, db: Session):
    book = get_book_by_id(book_id, db)
    db.delete(book)
    db.commit()


def borrow_book(book_id: int, user_id: int, db: Session):
    book = get_book_by_id(book_id, db)
    if book.available_copies < 1:
        raise HTTPException(status_code=400, detail="Book not available")

    active_borrows = db.query(BorrowRecord).filter(
        BorrowRecord.user_id == user_id,
        BorrowRecord.is_returned == False
    ).count()
    if active_borrows >= 3:
        raise HTTPException(status_code=400, detail="Borrow limit reached (max 3)")

    record = BorrowRecord(user_id=user_id, book_id=book_id)
    book.available_copies -= 1
    if book.available_copies == 0:
        book.available = False
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def return_book(book_id: int, user_id: int, db: Session):
    record = db.query(BorrowRecord).filter(
        BorrowRecord.user_id == user_id,
        BorrowRecord.book_id == book_id,
        BorrowRecord.is_returned == False
    ).first()
    if not record:
        raise HTTPException(status_code=404, detail="No active borrow found")

    book = get_book_by_id(book_id, db)
    book.available_copies += 1
    book.available = True
    record.is_returned = True
    db.commit()
    db.refresh(record)
    return record


def get_borrow_history(user_id: int, db: Session):
    return db.query(BorrowRecord).filter(BorrowRecord.user_id == user_id).all()