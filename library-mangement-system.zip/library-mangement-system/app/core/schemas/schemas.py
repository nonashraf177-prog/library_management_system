from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserLogin(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class UserOut(BaseModel):
    id: int
    username: str
    email: str
    role: str

    class Config:
        from_attributes = True


class BookCreate(BaseModel):
    title: str
    author: str
    total_copies: int = 1

class BookUpdate(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    total_copies: Optional[int] = None

class BookOut(BaseModel):
    id: int
    title: str
    author: str
    available: bool
    available_copies: int

    class Config:
        from_attributes = True


class BorrowOut(BaseModel):
    id: int
    book_id: int
    user_id: int
    borrowed_at: datetime
    is_returned: bool

    class Config:
        from_attributes = True