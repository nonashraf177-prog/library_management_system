# Library Management System - Documentation

## Project Overview
A RESTful API for managing a library system built with FastAPI, PostgreSQL, and Redis.

## Team Roles & Tasks

### 1. Lead Developer & Security
- Project structure setup
- JWT Authentication
- Role-based Authorization (Admin/Member)
- Database connection

### 2. Core CRUD Developer
- Books CRUD (Create, Read, Update, Delete)
- Search & Filtering
- Pagination
- Data Validation with Pydantic

### 3. Business Logic Developer
- Borrowing System
- Return System
- Borrow limit per user (max 3)
- Borrow history

### 4. Performance & Monitoring Engineer
- Redis Caching
- Structured Logging
- Monitoring Dashboard

### 5. DevOps (QA & DevOps Engineer)
- Unit Tests & Integration Tests (pytest)
- Docker & Docker-compose
- README Documentation

## How to Run

### With Docker
```bash
docker-compose up --build